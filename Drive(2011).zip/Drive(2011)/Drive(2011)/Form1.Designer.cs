﻿namespace Drive_2011_
{
    partial class IamRyanGosling
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnIDrive = new Button();
            lblLyrics = new Label();
            pbPics = new PictureBox();
            btnReal = new Button();
            btnFake = new Button();
            ((System.ComponentModel.ISupportInitialize)pbPics).BeginInit();
            SuspendLayout();
            // 
            // btnIDrive
            // 
            btnIDrive.Font = new Font("Mistral", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIDrive.ForeColor = Color.FromArgb(232, 3, 223);
            btnIDrive.Location = new Point(381, 495);
            btnIDrive.Name = "btnIDrive";
            btnIDrive.Size = new Size(122, 63);
            btnIDrive.TabIndex = 0;
            btnIDrive.Text = "I Drive";
            btnIDrive.UseVisualStyleBackColor = true;
            btnIDrive.Click += btnIDrive_Click;
            // 
            // lblLyrics
            // 
            lblLyrics.AutoSize = true;
            lblLyrics.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblLyrics.ImageAlign = ContentAlignment.TopLeft;
            lblLyrics.Location = new Point(416, 446);
            lblLyrics.Name = "lblLyrics";
            lblLyrics.Size = new Size(83, 32);
            lblLyrics.TabIndex = 1;
            lblLyrics.Text = "label1";
            lblLyrics.TextAlign = ContentAlignment.TopCenter;
            // 
            // pbPics
            // 
            pbPics.BackgroundImageLayout = ImageLayout.Zoom;
            pbPics.Image = Properties.Resources.i_ran;
            pbPics.Location = new Point(24, 24);
            pbPics.Name = "pbPics";
            pbPics.Size = new Size(823, 398);
            pbPics.SizeMode = PictureBoxSizeMode.Zoom;
            pbPics.TabIndex = 2;
            pbPics.TabStop = false;
            // 
            // btnReal
            // 
            btnReal.Font = new Font("Arial Narrow", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReal.ForeColor = Color.Black;
            btnReal.Location = new Point(256, 428);
            btnReal.Name = "btnReal";
            btnReal.Size = new Size(122, 63);
            btnReal.TabIndex = 3;
            btnReal.Text = "Real";
            btnReal.UseVisualStyleBackColor = true;
            btnReal.Click += btnReal_Click;
            // 
            // btnFake
            // 
            btnFake.Font = new Font("Arial Narrow", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnFake.ForeColor = Color.Black;
            btnFake.Location = new Point(509, 428);
            btnFake.Name = "btnFake";
            btnFake.Size = new Size(122, 63);
            btnFake.TabIndex = 4;
            btnFake.Text = "Fake";
            btnFake.UseVisualStyleBackColor = true;
            btnFake.Click += btnFake_Click;
            // 
            // IamRyanGosling
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(232, 192, 118);
            ClientSize = new Size(870, 579);
            Controls.Add(btnFake);
            Controls.Add(btnReal);
            Controls.Add(pbPics);
            Controls.Add(lblLyrics);
            Controls.Add(btnIDrive);
            Name = "IamRyanGosling";
            Text = "I Drive";
            Load += IamRyanGosling_Load;
            ((System.ComponentModel.ISupportInitialize)pbPics).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnIDrive;
        private Label lblLyrics;
        private PictureBox pbPics;
        private Button btnReal;
        private Button btnFake;
    }
}
