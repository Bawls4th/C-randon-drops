    namespace Drive_2011_
    {
    public partial class IamRyanGosling : Form
    {
        private string[] LiterallyMePics;
        private string[][] Nighcall;
        private int currentRyanGosling = 0;
        private int currentLyricIndex = 0;
        private const int RealorFayke = 4;
        private bool Survey = false;

        public IamRyanGosling()
        {
            InitializeComponent();
        }

        private void LoadImageFiles()
        {
            string imageFolder = @"C:\Users\Julius Mendoza\source\repos\Drive(2011)\Drive(2011)\Me Pictures";

            LiterallyMePics = Directory.GetFiles(imageFolder, "*.jpg", SearchOption.TopDirectoryOnly);

            if (LiterallyMePics.Length == 0)
            {
                MessageBox.Show("No images found in the specified folder.", "No Ryan Gosling Found.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            Nighcall = new string[LiterallyMePics.Length][];
            for (int i = 0; i < Nighcall.Length; i++)
            {
                Nighcall[i] = new string[]
                {
                        "There's Something Inside You",
                        "It's Hard To Explain",
                        "They're talking about you, boy",
                        "But you're still the same"
                };
            }
        }

        private void btnIDrive_Click(object sender, EventArgs e)
        {
            lblLyrics.Location = new Point(270,445);
            pbPics.BackgroundImage = null;

            if (LiterallyMePics == null || LiterallyMePics.Length == 0)
            {
                MessageBox.Show("No images to display.");
                Application.Exit();
                return;
            }

            string currentImagePath = LiterallyMePics[currentRyanGosling];
            pbPics.Image = Image.FromFile(currentImagePath);

            


            if (currentRyanGosling == RealorFayke)
            {
                if (!Survey)
                {
                    lblLyrics.Text = string.Empty;

                    MessageBox.Show("Real or Fake", "Survey", MessageBoxButtons.OK, MessageBoxIcon.Question);

                    lblLyrics.Text = "Or";
                    lblLyrics.Location = new Point(420, 445);
                    lblLyrics.TextAlign = ContentAlignment.MiddleCenter;
                    btnReal.Visible = true;
                    btnFake.Visible = true;

                    Survey = true;
                }
                else
                {
                    lblLyrics.Visible = true;
                    lblLyrics.Text = "Or";
                    lblLyrics.Location = new Point(420, 445);
                    lblLyrics.TextAlign = ContentAlignment.MiddleCenter;
                    MessageBox.Show("He's Literally Him.", "Hint", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                }

            }
            else
            {
                lblLyrics.Text = Nighcall[currentRyanGosling][currentLyricIndex];
                currentLyricIndex++;

                if (currentLyricIndex >= Nighcall[currentRyanGosling].Length)
                {
                    currentLyricIndex = 0;
                }

                currentRyanGosling++;

                if (currentRyanGosling >= LiterallyMePics.Length)
                {
                    currentRyanGosling = 0;
                }

                btnReal.Visible = false;
                btnFake.Visible = false;
                pbPics.Visible = true;

               
            }
        }

        private void IamRyanGosling_Load(object sender, EventArgs e)
        {
            LoadImageFiles();
            lblLyrics.Text = string.Empty;
            btnReal.Visible = false;
            btnFake.Visible = false;
        }

        private void btnReal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I am Ryan Gosling.", "He's Literally Him.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Application.Exit();
        }

        private void btnFake_Click(object sender, EventArgs e)
        {
            MessageBox.Show("There's only one correct answer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
